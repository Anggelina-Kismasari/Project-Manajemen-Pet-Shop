﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace PetShopManagement
{
    public partial class Home : Form
    {
        public Home()
        {
            InitializeComponent();
            CountFood();
            CountEquipment();
            CountDrugs();
        }
        SqlConnection Con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\ASUS\Documents\PetShopManagement.mdf;Integrated Security=True;Connect Timeout=30");
        private void CountFood()
        {
            string Cat = "Pet Food";
            Con.Open();
            SqlDataAdapter sda = new SqlDataAdapter("Select Count(*) from ProductTbl where PrCat='" + Cat + "'", Con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            FoodLbl.Text = dt.Rows[0][0].ToString();
            Con.Close();
        }
        private void CountEquipment()
        {
            string Cat = "Pet Equipment";
            Con.Open();
            SqlDataAdapter sda = new SqlDataAdapter("Select Count(*) from ProductTbl where PrCat='" + Cat + "'", Con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            EquipmentLbl.Text = dt.Rows[0][0].ToString();
            Con.Close();
        }
        private void CountDrugs()
        {
            string Cat = "Pet Drugs";
            Con.Open();
            SqlDataAdapter sda = new SqlDataAdapter("Select Count(*) from ProductTbl where PrCat='" + Cat + "'", Con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            DrugsLbl.Text = dt.Rows[0][0].ToString();
            Con.Close();
        }
        private void label3_Click(object sender, EventArgs e)
        {
            Products Obj = new Products();
            Obj.Show();
            this.Hide();
        }

        private void label4_Click(object sender, EventArgs e)
        {
            Employees Obj = new Employees();
            Obj.Show();
            this.Hide();
        }

        private void label5_Click(object sender, EventArgs e)
        {
            Customers Obj = new Customers();
            Obj.Show();
            this.Hide();
        }

        private void label7_Click(object sender, EventArgs e)
        {
            Login Obj = new Login();
            Obj.Show();
            this.Hide();
        }

        private void EquipmentLbl_Click(object sender, EventArgs e)
        {

        }
    }
}
